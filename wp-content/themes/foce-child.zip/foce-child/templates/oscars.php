<section id="oscars" class="oscars">
    <div class="blocImgText">
        <h3 class="txt-oscars">Fleurs d'oranger & Chats errants <br> est nominé aux Oscars Short <br> Film Animated de 2022 ! </h3>
    </div>
    <img class="logoscars" src="<?php echo get_theme_file_uri() . '/assets/images/logoscars.png'; ?>" alt="Logo des Oscars 2022">
</section>